package com.psl.training.oop.order;

public class StockItem {

	int itemNumber;
	String itemDescription;
	double itemPrice;
	
	int getQauntity()
	{
		return 0;
	}
}
