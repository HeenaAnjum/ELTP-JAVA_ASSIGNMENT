package com.psl.training.oop.order;

public class OrderItem {

	StockItem stockitem;
	int numberOfItems;
	
	public double getTotal()
	{
		return 0;
	}
}
