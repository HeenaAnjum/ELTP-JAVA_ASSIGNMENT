package com.psl.training.oop.shapes;

abstract public class Shape {

	public abstract void draw();
}



