package com.psl.training.oop.shapes;

public interface Bouncable {

	void bounce();
}
