package com.psl.training.oop.shapes;

public class Star extends Shape implements Sparkable {

	@Override
	public void spark() {
		// TODO Auto-generated method stub
		System.out.println("Star is Sparkling");
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
	System.out.println("Draw Star Shape");	
	}

}
