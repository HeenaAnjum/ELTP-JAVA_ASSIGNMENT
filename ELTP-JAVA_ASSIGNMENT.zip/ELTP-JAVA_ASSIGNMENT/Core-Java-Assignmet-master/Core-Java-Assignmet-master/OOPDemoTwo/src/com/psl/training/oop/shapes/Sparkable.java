package com.psl.training.oop.shapes;

public interface Sparkable {

	String DIRECTION = "In-Out Direction";
	void spark();
}
