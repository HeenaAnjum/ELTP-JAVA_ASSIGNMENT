package com.psl.training.oop.shapes;

public interface Rotatable {

	String DIRECTION ="Clockwise";
	void rotate();
}
